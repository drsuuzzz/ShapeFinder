
@protocol MobilityFunctionProtocol
- (double)valueAt:(double)x channel:(int)chan;
@end